import pickle


def unload_pickle(pickle_file_path, output_text_file_path):
    # Load data from pickle file
    with open(pickle_file_path, "rb") as pickle_file:
        data = pickle.load(pickle_file)

    # Write data to text file
    with open(output_text_file_path, "w") as text_file:
        text_file.write(str(data))
        # gold_texts = [entry["gold"] for entry in data if "gold" in entry]
        # for text in gold_texts:
        #     text_file.write(text + "\n")
        # text_file.write(str(gold_texts))


import json

# Open and read the file
with open("output.txt", "r") as file:
    data = json.load(file)

with open("our_output.txt", "w") as text_file:
    text_values = [entry["text"] for entry in data if "text" in entry]
    for text in text_values:
        text_file.write(text + "\n")


if __name__ == "__main__":
    pickle_file_path = "data.pkl"
    output_text_file_path = "data.txt"
    unload_pickle(pickle_file_path, output_text_file_path)
