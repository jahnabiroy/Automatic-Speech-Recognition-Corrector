import os
import sys
import pickle
import json
import argparse
from tqdm import tqdm
from copy import deepcopy
from time import time
import editdistance

import torch
from transformers import WhisperForConditionalGeneration, WhisperProcessor
from wrapt_timeout_decorator import timeout

DEVICE = 'cuda'

class Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, message):
        for stream in self.streams:
            stream.write(message)
            stream.flush()  # Ensure immediate writing (flushing)

    def flush(self):
        for stream in self.streams:
            stream.flush()

class CostModel(object):
    def __init__(self) -> None:
        # Load Whisper model and processor
        self.__processor = WhisperProcessor.from_pretrained("openai/whisper-tiny.en")
        self.__model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-tiny.en").to(DEVICE)
        self.__audio_inputs = None
        self.__ref_text = None
        self.__ref_cost = None
        self.__def_cost = 100.0
        self.__start_cost = None

    def set_audio(self, audio, sampling_rate, ref_text, start_text):
        self.__audio_inputs = self.__processor(
            audio, sampling_rate=sampling_rate, return_tensors="pt"
        ).input_features.to(DEVICE)
        self.__ref_text = ref_text
        self.__start_text = start_text
        self.__ref_wl = len(ref_text.split())
        self.__ref_cost = self._get_loss_noproc(ref_text)
        self.__start_cost = self._get_loss_noproc(start_text)
        # print('---> GOLD', self.__ref_cost)

    def _get_loss_noproc(self, text):
        # Prepare the target text input IDs
        target = self.__processor(
            text=text, return_tensors="pt", padding=True
        ).input_ids.to(DEVICE)

        # Make sure to set the decoder input IDs
        with torch.no_grad():
            outputs = self.__model(input_features=self.__audio_inputs, labels=target)

        loss = outputs.loss.item()
        loss = round(loss, 5)

        return loss

    def get_loss(self, text):
        # Prepare the target text input IDs
        if text is None:
            return 100.0

        if text == self.__ref_text:
            return self.__ref_cost

        edit = 1.0 * editdistance.distance(self.__ref_text, text)
        edit = edit / len(self.__ref_text)
        if edit > 0.6:
            return self.__start_cost * 10

        wl = len(text.split())
        if wl > self.__ref_wl + 2 or wl > 300:
            return self.__start_cost * 5

        cost = self._get_loss_noproc(text)
        cost = cost if cost >= self.__ref_cost else self.__ref_cost * 1.1

        return cost

class Environment(object):
    def __init__(self, init_state, cost_function, phoneme_table) -> None:
        self.init_state = init_state
        self.phoneme_table = deepcopy(phoneme_table)
        self.best_state = None
        self.__cost_function = cost_function

    def compute_cost(self, text):
        return self.__cost_function(text)

def run_with_timeout(agent, environment, time_out=-1):
    if time_out <= 0:
        agent.asr_corrector(environment)
        return

    @timeout(time_out)
    def fn():
        agent.asr_corrector(environment)
    fn()

    return


def add_results(file_path, new_data):
    # Check if the file exists and read the existing content
    if os.path.exists(file_path):
        with open(file_path, "r") as file:
            try:
                # Load the existing JSON data
                data = json.load(file)
            except json.JSONDecodeError:
                # If file is empty or corrupted, initialize an empty list
                data = []
    else:
        data = []
    
    # Ensure the data is a list so we can append to it
    if isinstance(data, list):
        data.append(new_data)
    else:
        raise TypeError("The existing data in the file is not a list.")

    # Write the updated data back to the file
    with open(file_path, "w") as file:
        json.dump(data, file, indent=2)


def main():
    parser = argparse.ArgumentParser(description="Process the input files with a timeout.")
    
    parser.add_argument('--input_file', type=str, help='Input filename')
    parser.add_argument('--timeout', type=int, help='Timeout value in seconds')
    parser.add_argument('--output_file', type=str, help='Output filename')
    parser.add_argument('--phoneme_file', type=str, help='Phoneme filename')
    parser.add_argument('--vocab_file', type=str, help='Vocabulary filename')
    parser.add_argument('--tag', type=str, help='tag', default='run')

    args = parser.parse_args()

    tag = args.tag
    output_file = open(f"{tag}.out", "w")
    error_file = open(f"{tag}.err", "w")
    original_stdout = sys.stdout
    original_stderr = sys.stderr
    sys.stdout = Tee(original_stdout, output_file)
    sys.stderr = Tee(original_stderr, error_file)

    with open(args.input_file, 'rb') as fp:
        data = pickle.load(fp)

    with open(args.phoneme_file, 'r') as fp:
        phoneme_table = json.load(fp)

    with open(args.vocab_file, 'r') as fp:
        vocabulary = json.load(fp)

    cost_model = CostModel()

    if os.path.exists(args.output_file):
        os.remove(args.output_file)

    from solution import Agent

    for sample in tqdm(data):
        audio = sample['audio']['array']
        sr = sample['audio']['sampling_rate']
        text = sample['text']

        gold = sample['gold']
        cost_model.set_audio(audio, sr, gold, text)

        environment = Environment(text, cost_model.get_loss, phoneme_table)

        stime = time()
        agent = Agent(deepcopy(phoneme_table), deepcopy(vocabulary))
        try:
            # agent.asr_corrector(environment)
            run_with_timeout(agent, environment, args.timeout)
            pred = agent.best_state
        except TimeoutError:
            print(f'Solver timed out')
            pred = agent.best_state
        except Exception as e:
            print(e.__class__, str(e))
            pred = None

        etime = time()
        result = {
            'text': pred,
            'runtime': etime - stime,
            'cost': cost_model.get_loss(pred) if pred is not None else None
        }

        add_results(args.output_file, result)

    sys.stdout = original_stdout
    sys.stderr = original_stderr
    output_file.close()
    error_file.close()


if __name__ == '__main__':
    main()
